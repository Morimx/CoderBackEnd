const connection = {
    client: 'mysql',
    connection:
    {
        host: "localhost",
        user: "claudio",
        password: "_pLhyp/@9HkqJBnU",
        database: "ecommerce",
        port: 3306
    }
};

export default connection;